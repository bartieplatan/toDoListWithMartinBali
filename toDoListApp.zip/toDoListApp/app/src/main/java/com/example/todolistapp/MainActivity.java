package com.example.todolistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.nio.Buffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText inputText;
    Button addBtn, openBtm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.textInp);
        addBtn = findViewById(R.id.addBtn);
        openBtm = findViewById(R.id.listBtn);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });
        openBtm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DataviewActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addItem(){
        String newItem = inputText.getText().toString();
        if (!newItem.isEmpty())
        {
            try {
                FileOutputStream file = openFileOutput("database.txt", Context.MODE_APPEND);
                file.write((newItem +"\n").getBytes());
                file.flush();
                file.close();

                Toast.makeText(getApplicationContext(),"Elem hozáadva!", Toast.LENGTH_SHORT).show();

                inputText.setText("");
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        else {
            Toast.makeText(getApplicationContext(),"A naplopást bünteti a törvény", Toast.LENGTH_SHORT).show();
        }
    }

}
package com.example.todolistapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class DataviewActivity extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datawiev);

        listView = findViewById(R.id.listView);
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,lisItems());

        listView.setAdapter(arrayAdapter);
    }

    public ArrayList lisItems(){
        ArrayList<String> arrayList = new ArrayList<>();

        try {
            FileInputStream file = openFileInput("database.txt");
            InputStreamReader fileReader = new InputStreamReader(file);

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuffer stringBuffer = new StringBuffer();

            String lines;
            while ((lines = bufferedReader.readLine()) != null){
                arrayList.add(lines);
                stringBuffer.append(lines+",");
                Log.i("",stringBuffer.toString());
            }
            return arrayList;
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        return arrayList;
    }
}
